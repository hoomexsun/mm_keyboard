	Install Eeyek (Unicode) Font

   1.  Go to the Windows\fonts\ folder on C: drive (or wherever Windows XP is installed)
      All the fonts installed in your machine are displayed here.

   2. Drag and drop the file Eeyek.ttf into this folder Windows\fonts\

After this step the font "Eeyek" would have been added successfully to your system´s Font Folder and you can use this font in any of your windows applications. 


	Installing Eeyek (Unicode) Font in Linux

Installing Meetei Mayek Font in Ubuntu is the easiest. Open the folder Eeyek_Unicode, double-click on the font file eeyek.ttf. It will open, showing the font characters, and there will be an install button on lower right corner. Click on it and the font will install.

Installing Meetei Mayek Font in other distributions of Linux is also as easy.

Basically, one has to copy the file Eeyek.ttf to the directory where
TrueType fonts are, /usr/share/fonts/truetype
or any other suitable folder in /usr/share/fonts/
Basically issue this command (as root):

# cp Eeyek.ttf /usr/share/fonts/truetype/

That's all. Restart your browser, and you should be able to see
Meetei Mayek webpages.
